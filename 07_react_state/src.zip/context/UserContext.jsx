import { createContext } from "react";
// 创建 Context
const UserContext = createContext();
export default UserContext
