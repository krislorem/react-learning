export default definePageConfig({
  navigationBarTitleText: '我的',
  navigationBarBackgroundColor: '#ec5f4a',
  navigationBarTextStyle: 'white',
})
