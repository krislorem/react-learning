export default definePageConfig({
    navigationBarTitleText: "Login",
});
