export default definePageConfig({
    navigationBarTitleText: "定位",
});
