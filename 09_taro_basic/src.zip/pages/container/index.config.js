export default definePageConfig({
    navigationBarTitleText: "Container",
});
