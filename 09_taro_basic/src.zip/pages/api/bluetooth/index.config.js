export default {
  navigationBarTitleText: '蓝牙'
}
