export default definePageConfig({
  navigationBarTitleText: 'API',
})
