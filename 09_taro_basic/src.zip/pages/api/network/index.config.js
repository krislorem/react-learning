export default {
  navigationBarTitleText: '网络请求演示'
}
