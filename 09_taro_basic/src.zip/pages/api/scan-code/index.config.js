export default {
  navigationBarTitleText: '扫码功能演示'
}
