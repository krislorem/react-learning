export default definePageConfig({
  navigationBarTitleText: "表单组件",
});
