export default definePageConfig({
    navigationBarTitleText: "地图",
});
