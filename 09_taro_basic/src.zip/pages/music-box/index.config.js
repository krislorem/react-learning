export default definePageConfig({
  navigationBarTitleText: "Audio Player",
});
