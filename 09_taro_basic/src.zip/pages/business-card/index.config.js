export default definePageConfig({
  navigationBarTitleText: "名片生成",
});
