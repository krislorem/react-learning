export default definePageConfig({
    navigationBarTitleText: "Contact",
});
