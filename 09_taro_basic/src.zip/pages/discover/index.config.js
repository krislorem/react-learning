export default definePageConfig({
    navigationBarTitleText: "Discover",
});
