export default definePageConfig({
  navigationBarTitleText: 'scrollview',
})
