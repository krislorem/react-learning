export default definePageConfig({
  navigationBarTitleText: 'webview',
})
