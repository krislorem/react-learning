export default definePageConfig({
  navigationBarTitleText: '组件',
})
