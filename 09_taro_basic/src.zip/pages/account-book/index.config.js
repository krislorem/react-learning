export default definePageConfig({
  navigationBarTitleText: "记账本",
});
