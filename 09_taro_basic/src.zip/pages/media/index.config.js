export default definePageConfig({
    navigationBarTitleText: "媒体组件",
});
