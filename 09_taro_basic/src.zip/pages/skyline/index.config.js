export default definePageConfig({
  navigationBarTitleText: "skyline",
});
