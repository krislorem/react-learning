export default definePageConfig({
    navigationBarTitleText: "Profile",
});
