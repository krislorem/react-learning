export default definePageConfig({
    navigationBarTitleText: "Product",
});
