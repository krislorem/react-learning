export default {
  navigationBarTitleText: '基础内容'
}
